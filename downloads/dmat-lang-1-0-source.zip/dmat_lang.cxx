#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

#include <iostream>
#include <vector>
#include <cmath>

struct Image {
    int width, height, channels;
    std::vector<unsigned char> data; // Assuming 4 bytes per pixel (RGBA)
};

Image loadImage(const char* filename) {
    Image img;
    unsigned char* data = stbi_load(filename, &img.width, &img.height, &img.channels, 4); // Force 4 channels (RGBA)
    if (data) {
        img.data.assign(data, data + img.width * img.height * 4);
        stbi_image_free(data);
    } else {
        std::cerr << "Failed to load image: " << filename << std::endl;
    }
    return img;
}

bool saveImage(const char* filename, const Image& img) {
    return stbi_write_png(filename, img.width, img.height, 4, img.data.data(), img.width * 4) != 0;
}

Image generateHeightMap(const Image& albedo) {
    Image heightMap;
    heightMap.width = albedo.width;
    heightMap.height = albedo.height;
    heightMap.channels = 1;
    heightMap.data.resize(albedo.width * albedo.height);

    for (int y = 0; y < albedo.height; ++y) {
        for (int x = 0; x < albedo.width; ++x) {
            int index = (y * albedo.width + x) * 4;
            unsigned char r = albedo.data[index];
            unsigned char g = albedo.data[index + 1];
            unsigned char b = albedo.data[index + 2];
            unsigned char gray = static_cast<unsigned char>(0.299f * r + 0.587f * g + 0.114f * b);
            heightMap.data[y * albedo.width + x] = gray;
        }
    }

    return heightMap;
}

Image generateNormalMap(const Image& heightMap) {
    Image normalMap;
    normalMap.width = heightMap.width;
    normalMap.height = heightMap.height;
    normalMap.channels = 4;
    normalMap.data.resize(heightMap.width * heightMap.height * 4);

    auto getPixel = [&](int x, int y) -> unsigned char {
        if (x < 0 || x >= heightMap.width || y < 0 || y >= heightMap.height)
            return 128; // Assume mid-gray for out-of-bound pixels
        return heightMap.data[y * heightMap.width + x];
    };

    for (int y = 0; y < heightMap.height; ++y) {
        for (int x = 0; x < heightMap.width; ++x) {
            float sx = (getPixel(x + 1, y) - getPixel(x - 1, y)) / 255.0f;
            float sy = (getPixel(x, y + 1) - getPixel(x, y - 1)) / 255.0f;
            float sz = 1.0f / std::sqrt(sx * sx + sy * sy + 1.0f);

            sx *= sz;
            sy *= sz;

            int index = (y * heightMap.width + x) * 4;
            normalMap.data[index] = static_cast<unsigned char>((sx + 1.0f) * 127.5f);
            normalMap.data[index + 1] = static_cast<unsigned char>((sy + 1.0f) * 127.5f);
            normalMap.data[index + 2] = static_cast<unsigned char>(sz * 255.0f);
            normalMap.data[index + 3] = 255;
        }
    }

    return normalMap;
}

Image generateRoughnessMap(const Image& albedo) {
    Image roughnessMap;
    roughnessMap.width = albedo.width;
    roughnessMap.height = albedo.height;
    roughnessMap.channels = 1;
    roughnessMap.data.resize(albedo.width * albedo.height);

    for (int y = 0; y < albedo.height; ++y) {
        for (int x = 0; x < albedo.width; ++x) {
            int index = (y * albedo.width + x) * 4;
            unsigned char r = albedo.data[index];
            unsigned char g = albedo.data[index + 1];
            unsigned char b = albedo.data[index + 2];

            float intensity = 0.299f * r + 0.587f * g + 0.114f * b;
            float roughness = 1.0f - intensity / 255.0f;
            roughnessMap.data[y * albedo.width + x] = static_cast<unsigned char>(roughness * 255.0f);
        }
    }

    return roughnessMap;
}

int main() {
    // Load your albedo image
    Image albedo = loadImage("a.png");
    if (albedo.data.empty()) {
        std::cerr << "Failed to load the albedo image." << std::endl;
        return -1;
    }

    // Generate maps
    Image heightMap = generateHeightMap(albedo);
    Image normalMap = generateNormalMap(heightMap);
    Image roughnessMap = generateRoughnessMap(albedo);

    // Save the generated maps
    if (!saveImage("height_map.png", heightMap)) {
        std::cerr << "Failed to save height map." << std::endl;
    }
    if (!saveImage("normal_map.png", normalMap)) {
        std::cerr << "Failed to save normal map." << std::endl;
    }
    if (!saveImage("roughness_map.png", roughnessMap)) {
        std::cerr << "Failed to save roughness map." << std::endl;
    }

    return 0;
}